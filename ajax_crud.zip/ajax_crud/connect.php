<?php 

$con = new mysqli('localhost', 'root', '', 'ajax_crud');

if(!$con)
{
    die(mysqli_error($con));
}

?> 
