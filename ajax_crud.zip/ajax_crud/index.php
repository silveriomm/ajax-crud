<?php 
include "connect.php";
include "delete.php";
?>
<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Ajax CRUD!</title>
    <link rel="stylesheet" href="css/bulma.min.css">
  </head>
  <body>
  <section class="section">
    <div class="container">
      <h1 class="subtitle has-text-centered">
        Ajax CRUD
      </h1>
     
        <button class="button is-primary js-modal-trigger" data-target="modal-insert">
            Novo usuário
        </button>
        
        <table class="table is-narrow is-fullwidth">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Nome</th>
                    <th>Sexo</th>
                    <th>Email</th>
                    <th>Telefone</th>
                    <th colspan="2"></th>
                </tr>
            </thead>
            <tbody>
                <?php 
                    $sql = "SELECT * FROM users ORDER BY id DESC";
                    $res = mysqli_query($con, $sql);
                    while($row=mysqli_fetch_assoc($res))
                    {
                ?>
                <tr>
                    <td><?= $row['id'] ?></td>
                    <td><?= $row['nome'] ?></td>
                    <td><?= $row['sexo'] ?></td>
                    <td><?= $row['email'] ?></td>
                    <td><?= $row['telefone'] ?></td>
                    <td>
                    <button class="button is-warning is-small js-modal-trigger" data-target="modal-update" onclick="updateUser(<?= $row['id']?>)">Editar</button>
                    </td>
                    <td>
                    <a href="?delete_id=<?= $row['id'] ?>" class="button is-danger is-small">Excluir</a>
                    </td>
                </tr>
                <?php } ?>
            </tbody>
        </table>

    </div>
  </section>
  </body>
  <script src="js/jquery.min.js"></script>
  <script src="js/modal.js"></script>
</html>

<!-- MODAL INSERT -->
<div class="modal" id="modal-insert">
  <div class="modal-background"></div>
  <div class="modal-card">
    <header class="modal-card-head">
      <p class="modal-card-title">Novo usuário</p>
      <button class="delete" aria-label="fechar"></button>
    </header>
    <section class="modal-card-body">
    <!-- FORM -->
    <form action="insert.php" method="post">
        <div class="field">
            <label>Nome</label>
            <input class="input" type="text" name="nome" id="nome" required autofocus>
        </div>
        <div class="field">
            <select name="sexo" id="sexo" class="input">
                <option value="">Escolha uma opção:</option>
                <option value="Feminino">Feminino</option>
                <option value="Masculino">Masculino</option>
            </select>
        </div>
        <div class="field">
            <label>Email</label>
            <input class="input" type="email" name="email" id="email" required>
        </div>
        <div class="field">
            <label>Telefone</label>
            <input class="input" type="text" name="telefone" id="telefone" required>
        </div>
    <footer class="modal-card-foot">
      <button class="button is-success" type="submit" name="save_user">Salvar</button>
      <a href="index.php" class="button">Cancelar</a>
    </footer>
    </form>
    </section>
    <!-- END FORM -->
  </div>
</div>
<!-- END MODAL INSERT -->


<script>
                        
// envia os dados para o formulário modal
function updateUser(update_id) {
    $('#hiddendata').val(update_id);

    $.post("update.php", {update_id:update_id}, function(data, status) {
        var user_id = JSON.parse(data);
        $('#unome').val(user_id.nome);
        $('#usexo').val(user_id.sexo);
        $('#uemail').val(user_id.email);
        $('#utelefone').val(user_id.telefone);
    });

    // $('#modal-update').modal("show");    
}

// atualiza os dados no banco
function updateUserSubmit() {
    var nome = $('#unome').val();
    var sexo = $('#usexo').val();
    var email = $('#uemail').val();
    var telefone = $('#utelefone').val();
    var hiddendata = $('#hiddendata').val();

    $.post("update.php", {
        nome: nome,
        sexo: sexo,
        email: email,
        telefone: telefone,
        hiddendata: hiddendata
    }, function(data, status){
        $('#modal-update').modal('hide');
    });
}

</script>

<!-- MODAL UPDATE -->
<div class="modal" id="modal-update">
  <div class="modal-background"></div>
  <div class="modal-card">
    <header class="modal-card-head">
      <p class="modal-card-title">Editar usuário</p>
      <button class="delete" aria-label="fechar"></button>
    </header>
    <section class="modal-card-body">
      <!-- FORM -->
    <form action="update.php" method="post">
        <div class="field">
            <label>Nome</label>
            <input class="input" type="text" name="unome" id="unome" required autofocus>
        </div>
        <div class="field">
            <select name="usexo" id="usexo" class="input">
                <option value="">Escolha uma opção:</option>
                <option value="Feminino">Feminino</option>
                <option value="Masculino">Masculino</option>
            </select>
        </div>
        <div class="field">
            <label>Email</label>
            <input class="input" type="email" name="uemail" id="uemail" required>
        </div>
        <div class="field">
            <label>Telefone</label>
            <input class="input" type="text" name="utelefone" id="utelefone" required>
        </div>
    <footer class="modal-card-foot">
      <button class="button is-success" type="submit" onclick="updateUserSubmit()">Salvar</button>
      <a href="index.php" class="button">Cancelar</a>
    </footer>
    <input type="hidden" name="hiddendata" id="hiddendata">
    </form>
    </section>
    <!-- END FORM -->
    </section>
  </div>
</div>
<!-- END MODAL UPDATE -->
