<?php 

include "connect.php";

if(isset($_GET['delete_id']))
{
    $id = $_GET['delete_id'];

    $sql = "DELETE FROM users WHERE id=$id";

    $res = mysqli_query($con, $sql);

    if($res)
    {
        header("location: index.php");
    }
}

?>
