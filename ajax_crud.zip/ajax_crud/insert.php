<?php 

include "connect.php";

if(isset($_POST['save_user']))
{
    $nome = $_POST['nome'];
    $sexo = $_POST['sexo'];
    $email = $_POST['email'];
    $telefone = $_POST['telefone'];

    $sql = "INSERT INTO users (nome, sexo, email, telefone) VALUES ('$nome', '$sexo', '$email', '$telefone')";

    $res = mysqli_query($con, $sql);

    if($res)
    {
        header("location: index.php");
    }
}

?>
